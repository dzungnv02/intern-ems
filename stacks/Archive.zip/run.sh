#!/bin/bash
docker-compose up -d > /dev/null 2>&1